# ⚡ ScrapeFlow — Assistant Scraping pour Freelances

Micro-SaaS qui automatise la collecte de contacts, produits et sites web.
Export CSV / Google Sheets / Excel.

---

## 🗂 Structure du projet

```
scrapeflow/
├── frontend/          # React + Vite
│   ├── src/App.jsx    # Interface principale
│   └── vite.config.js # Proxy dev → backend
├── backend/           # Node.js + Express
│   └── server.js      # Proxy sécurisé → Anthropic API
├── render.yaml        # Config déploiement Render
└── package.json       # Scripts racine
```

---

## 🚀 Démarrage local

### 1. Cloner & installer
```bash
git clone https://github.com/VOTRE_USERNAME/scrapeflow.git
cd scrapeflow
npm run install:all
```

### 2. Configurer les variables d'environnement
```bash
cd backend
cp .env.example .env
# Éditez .env et ajoutez votre clé Anthropic
```

### 3. Lancer en développement
```bash
cd ..
npm run dev
# Frontend → http://localhost:5173
# Backend  → http://localhost:3001
```

---

## ☁️ Déploiement sur GitHub + Render

### Étape 1 — Pusher sur GitHub
```bash
git init
git add .
git commit -m "🚀 Initial ScrapeFlow"
git remote add origin https://github.com/VOTRE_USERNAME/scrapeflow.git
git push -u origin main
```

### Étape 2 — Déployer le Backend sur Render
1. Allez sur [render.com](https://render.com) → **New → Web Service**
2. Connectez votre repo GitHub → sélectionnez `scrapeflow`
3. Paramètres :
   - **Root Directory** : `backend`
   - **Build Command** : `npm install`
   - **Start Command** : `npm start`
   - **Runtime** : Node
4. **Environment Variables** → ajoutez :
   - `ANTHROPIC_API_KEY` = votre clé (console.anthropic.com)
   - `FRONTEND_URL` = URL de votre frontend (à remplir après étape 3)
5. **Deploy** → notez l'URL du backend (ex: `https://scrapeflow-api.onrender.com`)

### Étape 3 — Déployer le Frontend sur Render
1. **New → Static Site**
2. Même repo → paramètres :
   - **Root Directory** : `frontend`
   - **Build Command** : `npm install && npm run build`
   - **Publish Directory** : `dist`
3. **Environment Variables** :
   - `VITE_API_URL` = URL du backend de l'étape 2
4. **Deploy** → votre app est en ligne ! 🎉

### Étape 4 — Relier frontend ↔ backend
- Retournez dans le service backend sur Render
- Mettez à jour `FRONTEND_URL` avec l'URL du frontend
- **Save & Redeploy**

---

## 🔑 Variables d'environnement

| Variable | Où | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | Backend | Clé API Anthropic (console.anthropic.com) |
| `FRONTEND_URL` | Backend | URL du frontend (pour CORS) |
| `VITE_API_URL` | Frontend | URL du backend |
| `PORT` | Backend | Port serveur (défaut: 3001) |

---

## 📦 Stack technique

- **Frontend** : React 18 + Vite 5
- **Backend** : Node.js + Express
- **IA** : Claude claude-sonnet-4-20250514 via Anthropic API
- **Deploy** : Render.com (free tier disponible)
- **Export** : CSV natif, Google Sheets (à brancher)

---

## 💡 Prochaines fonctionnalités

- [ ] Vrai scraping avec Puppeteer / Playwright
- [ ] Export Google Sheets via API
- [ ] Authentification utilisateurs (Clerk / Supabase)
- [ ] Paiement (Stripe) — plans Freelance / Pro
- [ ] Webhooks Zapier / Make
